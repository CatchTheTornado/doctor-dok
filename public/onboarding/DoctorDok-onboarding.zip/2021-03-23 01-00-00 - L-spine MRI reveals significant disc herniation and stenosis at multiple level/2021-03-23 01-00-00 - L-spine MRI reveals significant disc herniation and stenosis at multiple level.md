# DIKENGIL RADIOLOGY ASSOCIATES
DikengilRadiologyAssociates.com | 201-725-0913

**Phil Referrer, M. D.**  
0 Maywood Ave.  
Maywood, NJ 00000

**RE:** Jane, Mary; 38 F  
**Acct #:** 000006  
**DOB:** 00/00/1983  
**Study:** L-spine MRI  
**DOS:** 03/23/2021

---

### Clinical History:
38 year old female presenting with chronic right S1 radiculopathy.

### Technique:
Acquired on 1.5T System  
1. Sagittal: T1, T2, STIR  
2. Axial: T1, T2

### Findings:
- **Lumbar lordosis and alignment:** Preserved.
- **Vertebral bodies:** Normal in height and configuration.
- **Modic type I changes:** Prominent, discogenic Modic type I changes border the L5-S1 interspace.
- **Background marrow:** Reveals diminished fat signal characterizing red marrow reconversion.
- **Disc height loss:** Greater than 50% loss of disc height at L5-S1.
- **Disc desiccation:** All 3 disks of the L3-S1 segment are predominantly desiccated.

#### Analysis by axial levels:
- **L5-S1:** There is a large, polypoid inferiorly migrated disc herniation. This extrudes inferoposteriorly in the right parasagittal plane. Disruption of the annulus is estimated at 15 mm at its base. There is 12.2 mm posterior extrusion with approximately 2.2 cm inferior migration. The extruded disc markedly invaginates the right anterior quadrant of the thecal sac with 60% compromise of sac and occupying 40% of the central canal cross section effacement of the overall central canal parameters. There are severe central canal and focal right lateral recess stenoses. There are also severe bilateral foraminal stenoses, right greater than left.
- **L4-L5:** There is broad-based midline, subligamentous disc protrusion associated with degenerative facet, capsule and ligamentum flavum hypertrophy, resulting in borderline central canal stenosis.
- **L3-L4:** There is moderate circumferential annular bulge with superimposed mild disc protrusion against a background of similar degenerative hypertrophy of the posterior elements contributing to mild central canal stenosis.

The conus is normal in size and configuration and oriented with its tip at the T12-L1 interspace. Cauda equina nerve roots are thin and straight revealing no evidence of distortion or adhesion. The prevertebral soft tissues, and psoas-paraspinal musculature are symmetrically normal in caliber and signal.

### Conclusion:
1. At the L5-S1 level there is a large, right paracentral, inferiorly migrated polypoid central disc herniation resulting in severe partial thecal sac effacement and central canal stenosis, as detailed above.
2. At the L4-L5 and L3-L4 levels broad-based, midline, subligamentous disc protrusions are noted resulting in borderline central canal stenoses.

---

**Asim G Dikengil, M. D.**  
**DD:** 03/23/2021 **DT:** 03/23/2021

---

*This information is confidential and if you have received this email/fax in error please contact us immediately at 201-725-0913.*