# Test Report

## COMPLETE BLOOD COUNT; CBC

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Hemoglobin (Photometry)           | 15.00   | g/dL       | 13.00 - 17.00      |
| Packed Cell Volume (PCV)          | 45.00   | %          | 40.00 - 50.00      |
| RBC Count (Electrical Impedence)  | 4.50    | mill/mm3   | 4.50 - 5.50        |
| MCV (Electrical Impedence)        | 90.00   | fL         | 83.00 - 101.00     |
| MCH (Calculated)                  | 32.00   | pg         | 27.00 - 32.00      |
| MCHC (Calculated)                 | 33.00   | g/dL       | 31.50 - 34.50      |
| Red Cell Distribution Width (RDW) | 14.00   | %          | 11.60 - 14.00      |
| Total Leukocyte Count (TLC)       | 8.00    | thou/mm3   | 4.00 - 10.00       |
| Segmented Neutrophils             | 60.00   | %          | 40.00 - 80.00      |
| Lymphocytes                       | 30.00   | %          | 20.00 - 40.00      |
| Monocytes                         | 5.00    | %          | 2.00 - 10.00       |
| Eosinophils                       | 5.00    | %          | 1.00 - 6.00        |
| Basophils                         | 0.00    | %          | <2.00              |
| Platelet Count                    | 200     | thou/mm3   | 150.00 - 410.00    |
| Mean Platelet Volume              | 10.0    | fL         | 6.5 - 12.0         |

**Note:**
1. As per the recommendation of International council for Standardization in Hematology, the differential leucocyte counts are additionally being reported as absolute numbers of each cell in per unit volume of blood.
2. Test conducted on EDTA whole blood.

---

## LIVER & KIDNEY PANEL, SERUM

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Creatinine (Modified Jaffe,Kinetic) | 0.90   | mg/dL      | 0.70 - 1.30        |
| GFR Estimated (CKD EPI Equation 2021) | 118   | mL/min/1.73m2 | >59             |
| GFR Category (KDIGO Guideline 2012) | G1     |            |                    |
| Urea (Urease UV)                  | 20.00   | mg/dL      | 13.00 - 43.00      |
| Urea Nitrogen Blood (Calculated)  | 9.34    | mg/dL      | 6.00 - 20.00       |
| BUN/Creatinine Ratio (Calculated) | 10      |            |                    |
| Uric Acid (Uricase)               | 5.00    | mg/dL      | 3.50 - 7.20        |
| AST (SGOT) (IFCC without P5P)     | 11.0    | U/L        | 15.00 - 40.00      |
| ALT (SGPT) (IFCC without P5P)     | 21.0    | U/L        | 10.00 - 49.00      |
| GGTP (IFCC)                       | 11.0    | U/L        | 0 - 73             |
| Alkaline Phosphatase (ALP) (IFCC-AMP) | 150.00 | U/L      | 30.00 - 120.00     |
| Bilirubin Total (Oxidation)       | 0.20    | mg/dL      | 0.30 - 1.20        |
| Bilirubin Direct (Oxidation)      | 0.10    | mg/dL      | <0.3               |
| Bilirubin Indirect (Calculated)   | 0.10    | mg/dL      | <1.10              |
| Total Protein (Biuret)            | 7.00    | g/dL       | 5.70 - 8.20        |
| Albumin (BCG)                     | 4.00    | g/dL       | 3.20 - 4.80        |
| A : G Ratio (Calculated)          | 1.33    |            | 0.90 - 2.00        |
| Globulin (Calculated)             | 3.00    | gm/dL      | 2.0 - 3.5          |
| Calcium, Total (Arsenazo III)     | 8.00    | mg/dL      | 8.70 - 10.40       |

---

## LIPID SCREEN, SERUM

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Cholesterol, Total (CHO-POD)      | 105.00  | mg/dL      | <200.00            |
| Triglycerides (GPO-POD)           | 130.00  | mg/dL      | <150.00            |
| HDL Cholesterol (Enzymatic Immunoinhibition) | 46.00 | mg/dL | >40.00            |
| LDL Cholesterol, Calculated       | 33.00   | mg/dL      | <100.00            |
| VLDL Cholesterol, Calculated      | 26.00   | mg/dL      | <30.00             |
| Non-HDL Cholesterol, Calculated   | 59      | mg/dL      | <130               |

**Note:**
1. Measurements in the same patient can show physiological & analytical variations. Three serial samples 1 week apart are recommended for Total Cholesterol, Triglycerides, HDL & LDL Cholesterol.
2. Friedewald equation to calculate LDL cholesterol is most accurate when Triglyceride level is < 400 mg/dL. Measurement of Direct LDL cholesterol is recommended when Triglyceride level is > 400 mg/dL.
3. Lipid Association of India (LAI) recommends screening of all adults above the age of 20 years for lipid disorders.

---

## HbA1c (GLYCOSYLATED HEMOGLOBIN), BLOOD

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| HbA1c (HPLC, NGSP certified)      | 5.3     | %          | 4.00 - 5.60        |
| Estimated average glucose (eAG)   | 105     | mg/dL      |                    |

**Interpretation:**
HbA1c result is suggestive of non diabetic adults (>=18 years)/ well controlled Diabetes in a known Diabetic.

---

## GLUCOSE, FASTING (F), PLASMA

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Glucose Fasting (GOD POD)         | 90.00   | mg/dL      | 70 - 100           |

---

## THYROID PROFILE, TOTAL, SERUM

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| T3, Total (CLIA)                  | 2.00    | ng/mL      | 0.60 - 1.81        |
| T4, Total (CLIA)                  | 4.00    | µg/dL      | 5.01 - 12.45       |
| TSH (CLIA)                        | 4.00    | µIU/mL     | 0.550 - 4.780      |

**Note:**
1. TSH levels are subject to circadian variation, reaching peak levels between 2 - 4.a.m. and at a minimum between 6-10 pm. The variation is of the order of 50%. Hence time of the day has influence on the measured serum TSH concentrations.
2. Alteration in concentration of Thyroid hormone binding protein can profoundly affect Total T3 and/or Total T4 levels especially in pregnancy and in patients on steroid therapy.
3. Unbound fraction (Free,T4 /Free,T3) of thyroid hormone is biologically active form and correlate more closely with clinical status of the patient than total T4/T3 concentration.
4. Values <0.03 uIU/mL need to be clinically correlated due to presence of a rare TSH variant in some individuals.

---

## VITAMIN B12; CYANOCOBALAMIN, SERUM

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Vitamin B12 (CLIA)                | 280.00  | pg/mL      | 211.00 - 911.00    |

**Notes:**
1. Interpretation of the result should be considered in relation to clinical circumstances.
2. It is recommended to consider supplementary testing with plasma Methylmalonic acid (MMA) or plasma homocysteine levels to determine biochemical cobalamin deficiency in presence of clinical suspicion of deficiency but indeterminate levels. Homocysteine levels are more sensitive but MMA is more specific.
3. False increase in Vitamin B12 levels may be observed in patients with intrinsic factor blocking antibodies, MMA measurement should be considered in such patients.
4. The concentration of Vitamin B12 obtained with different assay methods cannot be used interchangeably due to differences in assay methods and reagent specificity.

---

## VITAMIN D, 25 - HYDROXY, SERUM

| Test Name                        | Results | Units      | Bio. Ref. Interval |
|-----------------------------------|---------|------------|--------------------|
| Vitamin D, 25 - Hydroxy (CLIA)    | 85.00   | nmol/L     | 75.00 - 250.00     |

**Interpretation:**
- Deficient: < 50 nmol/L (High risk for developing bone disease)
- Insufficient: 50-74 nmol/L (Vitamin D concentration which normalizes Parathyroid hormone concentration)
- Sufficient: 75-250 nmol/L (Optimal concentration for maximal health benefit)
- Potential intoxication: >250 nmol/L (High risk for toxic effects)

**Note:**
- The assay measures both D2 (Ergocalciferol) and D3 (Cholecalciferol) metabolites of vitamin D.
- 25 (OH)D is influenced by sunlight, latitude, skin pigmentation, sunscreen use and hepatic function.
- Optimal calcium absorption requires vitamin D 25 (OH) levels exceeding 75 nmol/L.

---

## Comments on Vitamin D

- Vitamin D promotes absorption of calcium and phosphorus and mineralization of bones and teeth. Deficiency in children causes Rickets and in adults leads to Osteomalacia. It can also lead to Hypocalcemia and Tetany. Vitamin D status is best determined by measurement of 25 hydroxy vitamin D, as it is the major circulating form and has longer half life (2-3 weeks) than 1,25 Dihydroxy vitamin D (5-8 hrs).
  
**Decreased Levels:**
- Inadequate exposure to sunlight
- Dietary deficiency
- Vitamin D malabsorption
- Severe Hepatocellular disease
- Drugs like Anticonvulsants
- Nephrotic syndrome

**Increased levels:**
- Vitamin D intoxication