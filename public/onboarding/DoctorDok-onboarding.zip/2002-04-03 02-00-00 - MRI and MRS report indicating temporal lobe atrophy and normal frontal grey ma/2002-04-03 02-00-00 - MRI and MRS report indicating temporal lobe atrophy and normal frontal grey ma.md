# Clinical Spectroscopy Report

**Patient:** [REDACTED]  
**Age:** [REDACTED]  
**DOB:** [REDACTED]  
**Sex:** [REDACTED]  
**Exam Type:** MRI and 1H MRS  
**Exam Date:** [REDACTED]  
**Program:** Dementia  
**Sub Program:** [REDACTED]  
**Previous MRS Exams:** 1

## Clinical Indications
Memory loss for 2 years. MRI shows temporal lobe atrophy. MRS shows decreased NAA and increased mI consistent with AD. However, the patient has diabetes mellitus, and Dr. [REDACTED] suspects frontal lobe dementia.

## MRI Technique
- **T2 Axial, FLAIR**
- **Voxel:** (1) Frontal grey matter, (2) Post cingulate gyrus

## MRS Technique
- **TE 35; PROBE SV**

## MRI Results
As reported. New voxel located in anterior cingulate gyrus grey matter as defined for FLD diagnosis.

## MRS Results
**Location 1 (volume of interest): Frontal grey matter**  
- **Patient NAA:** 1.32  
- **Normal NAA:** 1.38  
- **Patient Cho:** 0.87  
- **Normal Cho:** 0.87  
- **Patient mI:** 0.74  
- **Normal mI:** 0.72  
- **Patient α-Glx:** [REDACTED]  
- **Normal α-Glx:** [REDACTED]  
- **Patient β,γ-Glx:** [REDACTED]  
- **Normal β,γ-Glx:** [REDACTED]

**PRESS TE 35; 8 cm3**  
Excellent technical quality apart from small extra-axial lipid peak of no diagnostic significance. GE-machine values given showing no reduction of NAA and no increase of mI. This makes FLD an unlikely contributor to the dementia.

**Location 2 (volume of interest): Post cingulate gyrus**  
- **Patient NAA:** 1.03  
- **Normal NAA:** 1.40  
- **Patient Cho:** 0.75  
- **Normal Cho:** 0.66  
- **Patient mI:** 0.71  
- **Normal mI:** 0.63  
- **Patient α-Glx:** [REDACTED]  
- **Normal α-Glx:** [REDACTED]  
- **Patient β,γ-Glx:** [REDACTED]  
- **Normal β,γ-Glx:** [REDACTED]

**STEAM 30 ms; 8 cm3**  
Excellent technical result using alternate PROBE-STEAM 30 ms TE. NAA/Cr is reduced by 30%; mI/Cr is increased by 12%. Cho/Cr is slightly above normal. Brain glucose is higher today than 4/3/02. Confirms AD diagnosis performed on 4/3/02 using PRESS technique.

## Impression
1. A further series of spectra were acquired to optimize Alzheimer diagnostic parameters. Not of further diagnostic importance.
2. MRI: Previously reported temporal lobe atrophy.
3. MRS: 
   - (1) Frontal grey matter is NORMAL.
   - (2) Alzheimer diagnosis is reinforced by findings using an alternate MRS technique (STEAM).
   - (3) Elevated brain glucose (blood not sampled).

Thank you for referring this patient.

**Physician:** Brian D. Ross, M.D., Ph.D.  
**Date:** [REDACTED]  
**MM:** [REDACTED]  
**dd:** [REDACTED]  
**dt:** [REDACTED]